#include <iostream>
#include <sstream>
#include "TMath.h"
#include "TSystem.h"
#include "TFile.h"
#include "TStyle.h"
#include "TCanvas.h"
#include "TPad.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TText.h"
#include "TPaveLabel.h"
#include "TLine.h"
#include "TLegend.h"

#include "PlotCompareUtility.h"
#include "HistoData.h"
using namespace std;

const bool KS_TEST = false;
const bool CHI2_TEST = true;

int main(int argc, char *argv[]) {

  // make sure command line arguments were supplied
  if (argc != 6) { cerr << "Usage: " << argv[0] << " [reference.root] [new-comparison.root] [root-dir] [new-release] [old-release] \n"; return 1; }

  // create the comparison class
  PlotCompareUtility *pc = new PlotCompareUtility(argv[1],argv[2],argv[3],"METTask_HCAL_");
  HistoData *hd;

  if (pc->GetStatus() != 0) { cout << "Final Result: no_data" << endl; return 0; }

  // add histogram information
  
  hd = pc->AddHistoData("D4_Occ_ieta_iphi"); hd->SetType(1); hd->SetValueX("D4 Occupancy");  
  hd = pc->AddHistoData("D3_Occ_ieta_iphi"); hd->SetType(1); hd->SetValueX("D3 Occupancy");
  hd = pc->AddHistoData("D2_Occ_ieta_iphi"); hd->SetType(1); hd->SetValueX("D2 Occupancy");
  hd = pc->AddHistoData("D1_Occ_ieta_iphi"); hd->SetType(1); hd->SetValueX("D1 Occupancy");

  hd = pc->AddHistoData("D4_Occvsieta"); hd->SetType(2); hd->SetValueX("D4 Occupancy");
  hd = pc->AddHistoData("D3_Occvsieta"); hd->SetType(2); hd->SetValueX("D3 Occupancy");
  hd = pc->AddHistoData("D2_Occvsieta"); hd->SetType(2); hd->SetValueX("D2 Occupancy");
  hd = pc->AddHistoData("D1_Occvsieta"); hd->SetType(2); hd->SetValueX("D1 Occupancy");

  hd = pc->AddHistoData("D4_METPhivsieta"); hd->SetType(2); hd->SetValueX("MET-#phi (radians)");
  hd = pc->AddHistoData("D3_METPhivsieta"); hd->SetType(2); hd->SetValueX("MET-#phi (radians)");
  hd = pc->AddHistoData("D2_METPhivsieta"); hd->SetType(2); hd->SetValueX("MET-#phi (radians)");
  hd = pc->AddHistoData("D1_METPhivsieta"); hd->SetType(2); hd->SetValueX("MET-#phi (radians)");

  hd = pc->AddHistoData("D4_MEyvsieta"); hd->SetType(2); hd->SetValueX("METy (GeV)");
  hd = pc->AddHistoData("D3_MEyvsieta"); hd->SetType(2); hd->SetValueX("METy (GeV)");
  hd = pc->AddHistoData("D2_MEyvsieta"); hd->SetType(2); hd->SetValueX("METy (GeV)");
  hd = pc->AddHistoData("D1_MEyvsieta"); hd->SetType(2); hd->SetValueX("METy (GeV)");

  hd = pc->AddHistoData("D4_MExvsieta"); hd->SetType(2); hd->SetValueX("METx (GeV)");
  hd = pc->AddHistoData("D3_MExvsieta"); hd->SetType(2); hd->SetValueX("METx (GeV)");
  hd = pc->AddHistoData("D2_MExvsieta"); hd->SetType(2); hd->SetValueX("METx (GeV)");
  hd = pc->AddHistoData("D1_MExvsieta"); hd->SetType(2); hd->SetValueX("METx (GeV)");

  hd = pc->AddHistoData("D4_METvsieta"); hd->SetType(2); hd->SetValueX("MET (GeV)");
  hd = pc->AddHistoData("D3_METvsieta"); hd->SetType(2); hd->SetValueX("MET (GeV)");
  hd = pc->AddHistoData("D2_METvsieta"); hd->SetType(2); hd->SetValueX("MET (GeV)");
  hd = pc->AddHistoData("D1_METvsieta"); hd->SetType(2); hd->SetValueX("MET (GeV)");
  
  hd = pc->AddHistoData("D4_SETvsieta"); hd->SetType(2); hd->SetValueX("SET (GeV)");
  hd = pc->AddHistoData("D3_SETvsieta"); hd->SetType(2); hd->SetValueX("SET (GeV)");
  hd = pc->AddHistoData("D2_SETvsieta"); hd->SetType(2); hd->SetValueX("SET (GeV)");
  hd = pc->AddHistoData("D1_SETvsieta"); hd->SetType(2); hd->SetValueX("SET (GeV)");
  
  hd = pc->AddHistoData("D4_energyvsieta"); hd->SetType(2); hd->SetValueX("D4 energy (GeV)");
  hd = pc->AddHistoData("D3_energyvsieta"); hd->SetType(2); hd->SetValueX("D3 energy (GeV)");
  hd = pc->AddHistoData("D2_energyvsieta"); hd->SetType(2); hd->SetValueX("D2 energy (GeV)");
  hd = pc->AddHistoData("D1_energyvsieta"); hd->SetType(2); hd->SetValueX("D1 energy (GeV)");

  if (pc->GetStatus() != 0) { cerr << "error encountered, exiting.\n"; return pc->GetStatus(); }

  // create overview results summary histogram
  int num_histos = pc->GetNumHistos();
  TH1F h2dResults("h2dResults","h2dResults", num_histos, 1, num_histos + 1);

  // get the reference and comparison Nevents (not Nentries)	
  int Nevents_ref = ((TH1F *)pc->GetRefHisto("Nevents"))->GetEntries();
  int Nevents_new = ((TH1F *)pc->GetNewHisto("Nevents"))->GetEntries();
  int Nevents = -1;
  if (Nevents_ref>Nevents_new) Nevents = Nevents_ref;
  else Nevents = Nevents_new;

// arrays/variables to store test scores and overall pass/fail evaluations
  float low_score[num_histos], high_score[num_histos];
  bool combinedFailed = false;
  bool testFailed[num_histos];
  bool empty[num_histos];
  int types[num_histos];

  for (int index = 0; index < num_histos; index++) {

    // initialize. memset to non-zero is dangerous with float types
    low_score[index] = 1;
    high_score[index] = 0;
    testFailed[index] = false;
    empty[index] = true;
    types[index] = 0;

  }

  float threshold = KS_TEST ? pc->GetKSThreshold() : pc->GetChi2Threshold();


  // loop over the supplied list of histograms for comparison
  for (int index = 0; index < pc->GetNumHistos(); index++) {

    int number = index + 1;
    hd = pc->GetHistoData(number);
    int type = hd->GetType();
    types[index] = type;
    string name = hd->GetName();
    string value = hd->GetValueX();
    cout << name << endl;

    // get the reference and comparison 2d histograms
    TH2F *hnew2d = (TH2F *)pc->GetNewHisto(name);
    TH2F *href2d = (TH2F *)pc->GetRefHisto(name);

    // set this histograms label in the allResults histo
    h2dResults.GetXaxis()->SetBinLabel(number, name.c_str());

    // ignore if histogram is broken
    if (hnew2d->GetEntries() <= 1 || href2d->GetEntries() <= 1) {
      cout << "problem with histogram " << name << endl; continue;
    }

    // create 1d histograms to put projection results into
    string titleP = "h1dResults_passed_" + name;
    string titleF = "h1dResults_failed_" + name;
    string titleN = "h1dResults_noTest_" + name;
    TH1F h1dResults_passed(titleP.c_str(),titleP.c_str(),83,-41,42);
    TH1F h1dResults_failed(titleF.c_str(),titleF.c_str(),83,-41,42);    
    TH1F h1dResults_noTest(titleF.c_str(),titleN.c_str(),83,-41,42);

    // create a subdirectory in which to put resultant histograms
    gSystem->mkdir(name.c_str());

    // loop over ieta
    float running_result = 0; int counted_bins = 0;
    for (int bin = 1; bin <= href2d->GetNbinsX(); bin++) {

      int ieta = bin - 42;
      stringstream bin_label;
      bin_label << ieta;

      // ignore the center bin
      if (bin == 42) continue;

      // unique names should _NOT_ be used (ProjectionY will re-alloc memory
      // each time... But... Root is buggy and won't reliably display)....
      stringstream hname_new, hname_ref;
      hname_new << "tmp_hnew_" << name << "_" << bin;
      hname_ref << "tmp_href_" << name << "_" << bin;

      // get the 1d projection for this ieta bin out of the histogram
      TH1D *hnew = hnew2d->ProjectionY(hname_new.str().c_str(),bin,bin);
      TH1D *href = href2d->ProjectionY(hname_ref.str().c_str(),bin,bin);

      // ignore empty bins
      if (hnew->Integral() == 0 || href->Integral() == 0) { 
        cout << "  ieta = " << ieta << ": empty!" << endl;
	h1dResults_noTest.SetBinContent(bin,1);
        continue;
      } else { empty[index] = false; }

      float ks_score, chi2_score, result;
      
      // calculate and set range and number of bins
      double h1RMS =  hnew->GetRMS();
      double h2RMS =  href->GetRMS();
      double RMS = TMath::Max(h1RMS, h2RMS);
      double h1Mean =  hnew->GetMean();
      double h2Mean =  href->GetMean();
      double Mean = 0.5 * (h1Mean + h2Mean);
      double Nbins = href->GetNbinsX();
      double min = href->GetXaxis()->GetXmin();
      double max = href->GetXaxis()->GetXmax();
      double dX = max - min;
      double dNdX = 1;
      double NewMin = 0;
      double NewMax = 1;
      if (RMS>0) 
	{
	  dNdX = 100. / ( 10 * RMS);
	  NewMin = Mean - 5 * RMS;
	  NewMax = Mean + 5 * RMS;
	}
      
      int rebinning = 1;
      if ((dX * dNdX)>0) 
	rebinning = (int)(double(Nbins) / (dX * dNdX));
          
      // histograms of this type should be rescaled and rebinned
      if (type == 2) {
	href->GetXaxis()->SetRangeUser(NewMin, NewMax);
	hnew->GetXaxis()->SetRangeUser(NewMin, NewMax);
	
	if (rebinning > 1) {
	  href->Rebin(rebinning);
	  hnew->Rebin(rebinning);
	}
	
      } 
      
      href->GetXaxis()->SetTitle(value.c_str());
      href->GetYaxis()->SetTitle("Entries");
      href->GetYaxis()->SetTitleOffset(1.5);
//      href->SetNormFactor(hnew->GetEntries());
      href->SetNormFactor(Nevents_new);
      hnew->SetNormFactor(Nevents_new);		     
 
      ks_score = hnew->KolmogorovTest(href);
      chi2_score = hnew->Chi2Test(href );
      result = (ks_score>chi2_score) ? ks_score : chi2_score;
      running_result += result; counted_bins++;

      if (result > high_score[index]) { high_score[index] = result; }
      if (result < low_score[index]) { low_score[index] = result; }

        href->SetNormFactor(Nevents_new);
//      href->SetNormFactor(hnew->GetEntries());

      // ensure that the peaks of both histograms will be shown by making a dummy histogram
      float Nentries_ref = href->GetEntries();
      float Nentries_new = hnew->GetEntries();
      float XaxisMin_ref = 0, XaxisMax_ref = 0, YaxisMin_ref = 0, YaxisMax_ref = 0;
      float XaxisMin_new = 0, XaxisMax_new = 0, YaxisMin_new = 0, YaxisMax_new = 0;
      if (Nentries_ref>0) YaxisMax_ref = (href->GetMaximum()+TMath::Sqrt(href->GetMaximum()))*(Nentries_new/Nentries_ref);
      if (Nentries_new>0) YaxisMax_new = (hnew->GetMaximum()+TMath::Sqrt(hnew->GetMaximum()));
      
      XaxisMin_ref = href->GetXaxis()->GetXmin()>NewMin  ? href->GetXaxis()->GetXmin() : NewMin;
      XaxisMax_ref = href->GetXaxis()->GetXmax()<=NewMax ? href->GetXaxis()->GetXmax() : NewMax;
      YaxisMax_ref = (YaxisMax_ref>=YaxisMax_new) ? YaxisMax_ref : YaxisMax_new;

      if (TMath::Abs(XaxisMin_ref - XaxisMax_ref)<1E-6)
	{
	  XaxisMin_ref = 0;
	  XaxisMax_ref = 1;
	}

      TH1F *hdumb = new TH1F("hdumb","", rebinning, XaxisMin_ref, XaxisMax_ref);
      hdumb->SetMinimum(1E-1);
      hdumb->SetMaximum(1.05*YaxisMax_ref);

      // set drawing options on the reference histogram
      href->SetStats(0);
      href->SetLineWidth(2);
      href->SetLineColor(14);
      href->SetMarkerColor(14);
      href->SetFillColor(17);
      //href->SetFillStyle(3001);

      // set drawing options on the new histogram
      hnew->SetStats(0);
      hnew->SetLineWidth(2);
      hnew->SetFillStyle(3001);

      // set drawing options on the dummy histogram
      hdumb->SetStats(0);
      TString title_ = value.c_str(); title_+= " [i#eta = " ; title_+=ieta; title_+="]";
      hdumb->GetXaxis()->SetTitle(title_);
      hdumb->GetXaxis()->SetTitleSize(0.04);
      hdumb->GetXaxis()->SetLabelSize(0.03);
      hdumb->GetYaxis()->SetTitle("Entries");
      hdumb->GetYaxis()->SetTitleOffset(1.5);
      hdumb->GetYaxis()->SetLabelSize(0.03);

      stringstream ss_title;
      ss_title.precision(5);
      if (ks_score>chi2_score)
	ss_title << "KS Score = " << ks_score;
      else
	ss_title << "Chi^2 Score = " << chi2_score;
      TText canvas_title(0.15,0.97,ss_title.str().c_str());

      if (result <= threshold) {

        // make this histogram red to denote failure
        hnew->SetFillColor(kRed);
        hnew->SetLineColor(206);
        hnew->SetMarkerColor(206);

        // mark the sample as being 'not-compatible'
        testFailed[index] = true;
        combinedFailed = true;

        // set the summary bin to failed (only need to set titles for passed h1dResults)
        h1dResults_failed.SetBinContent(bin,result);

        // set the canvas title
        canvas_title.SetTextColor(kRed);

      } else {

        // make this histogram green to denote passing
        hnew->SetFillColor(kGreen);
        hnew->SetLineColor(103);
        hnew->SetMarkerColor(103);

        // set the summary bin to passed
        h1dResults_passed.SetBinContent(bin,result);

        // set the canvas title
        canvas_title.SetTextColor(kGreen);

      }

      // setup canvas for displaying the compared histograms
      TCanvas histo_c("histo_c","histo_c",785,800);
      histo_c.Draw();

      TPad histo_p("histo_p","histo_p",0.01,0.01,0.99,0.94);
      histo_p.Draw();

      histo_c.cd();
      canvas_title.SetTextSize(0.025);
      canvas_title.Draw();

      histo_p.cd();
      histo_p.SetLogy(1);
      hdumb->Draw();
      href->Draw("SAME");
      hnew->Draw("SAME");
      hnew->Draw("E1SAME");

    stringstream legend_new;
    stringstream legend_ref;
    legend_new << argv[4] << ": " << Nentries_new << " entries";
    legend_ref << argv[5] << ": " << Nentries_ref << " entries";		
	
    TLegend l1(0.15,0.01,0.33, 0.09);
    l1.SetTextSize(0.022);
    l1.AddEntry(hnew, legend_new.str().c_str(),"lF");
    l1.AddEntry(href, legend_ref.str().c_str(),"lF");
    l1.SetFillColor(kNone);      
    l1.Draw("SAME");

   
      // print the result to gif
      stringstream histo_name;
      histo_name << name << "/Compare_ietaBin";
      if (bin < 10) histo_name << "00";
      else if (bin < 100) histo_name << "0";
      histo_name << bin << ".gif";
      histo_c.Print(histo_name.str().c_str(),"gif");

      // report the obtained KS score
      cout << "  ieta = " << ieta << ": result = " << result << endl; 

    } // end loop over ieta bins

    // create ieta summary canvas
    TCanvas ieta_c("ieta_c","ieta_c",1000,500);
    ieta_c.Draw();

    TPad ieta_p("ieta_p","ieta_p",0,0,1,1);
    ieta_p.SetLogy(1);
    ieta_p.SetFrameFillColor(10);
    ieta_p.Draw();

    ieta_c.cd();
    TText ieta_title(.01, .01, "");
    ieta_title.Draw("SAME");

    ieta_p.cd();

    // setup the passing test bars
    h1dResults_passed.SetStats(0);
    h1dResults_passed.GetXaxis()->SetLabelSize(0.03);
    h1dResults_passed.GetXaxis()->SetTitle("i#eta Ring");
    h1dResults_passed.GetYaxis()->SetTitle("Compatibility");
    h1dResults_passed.GetYaxis()->SetLabelSize(0.03);
    h1dResults_passed.SetBarWidth(0.7);
    h1dResults_passed.SetBarOffset(0.1);
    h1dResults_passed.GetYaxis()->SetRangeUser(1E-7,2);

    // setup the failing test bars
    h1dResults_failed.SetStats(0);
    h1dResults_failed.SetBarWidth(0.7);
    h1dResults_failed.SetBarOffset(0.1);
    h1dResults_failed.GetYaxis()->SetRangeUser(1E-7,2);

    h1dResults_noTest.SetStats(0);
    h1dResults_noTest.SetBarWidth(1);
    h1dResults_noTest.SetBarOffset(0.0);
    h1dResults_noTest.SetFillColor(kBlack);
    h1dResults_noTest.SetFillStyle(3004);
    h1dResults_noTest.GetYaxis()->SetRangeUser(1E-7,2);

    if (empty[index]) {
      // do nothing
    } else {
      h1dResults_passed.SetFillColor(kGreen);
      h1dResults_passed.SetLineColor(kGreen);
      h1dResults_failed.SetFillColor(kRed);
      h1dResults_failed.SetLineColor(kRed);
      h1dResults_passed.Draw("bar");
      h1dResults_failed.Draw("barSAME");
      h1dResults_noTest.Draw("barSAME");
    }

    // draw the pass/fail threshold line
    TLine l(-41, threshold, 42, threshold);
    l.SetLineColor(kRed);
    l.SetLineWidth(2);
    l.SetLineStyle(2);
    l.Draw("SAME");

    // print the results
    ieta_c.Update();
    string ieta_name = name + "/Results_vs_etaRing.gif";
    ieta_c.Print(ieta_name.c_str(),"gif");
     
    // report the result of the tests, if performed
    cout << "result is: ";
    if (type == 1) cout << "no determination made";
    else if (testFailed[index]) cout << "fail";
    else if (empty[index]) cout << "no data";
    else cout << "pass";
    float mean = counted_bins > 0 ? running_result / counted_bins : 0;
    cout << ", mean KS score = " << mean << endl;



  } // end loop over 2d histograms

  // create summary canvas
  int summary_height = int(780 * float(num_histos) / 22); // 780;
  TCanvas main_c("main_c","main_c",799,summary_height);
  main_c.Draw();

  TPad main_p("main_p","main_p",0.01,0.01,0.99,0.94);
  main_p.SetLeftMargin(0.30);
  main_p.SetBottomMargin(0.15);
  main_p.SetLogx(1);
  main_p.SetGrid();
  main_p.SetFrameFillColor(10);
  main_p.Draw();

  main_c.cd();
  TText summary_title(.01, .95, "");
  summary_title.Draw("SAME");

  main_p.cd();

  // this histogram should be empty -- filling only with the TBox objects
  h2dResults.SetStats(0);
  h2dResults.SetBarWidth(0.45);
  h2dResults.SetBarOffset(0.1);
  h2dResults.GetYaxis()->SetRangeUser(1E-7,2);
  h2dResults.GetYaxis()->SetTitle("Compatibility");
  h2dResults.SetBinContent(1,0.5);
  h2dResults.SetLabelSize(0.08*22.0/(1+float(num_histos)));
  h2dResults.GetYaxis()->SetLabelSize(0.04*22.0/(1.0+float(num_histos)));
  h2dResults.GetXaxis()->SetLabelSize(0.05*22.0/(1.0+float(num_histos))); 
  h2dResults.Draw("hbar");

  // fill in a display box on the overview compatibility range histogram
  TBox box;
  box.SetLineWidth(2);
  for (int i = 0; i < num_histos; i++) {

    // form a display box based on the range of scores
    float box_min = low_score[i];
    float box_max = high_score[i];

    // ensure that the box does not go below the range of the results histo
    if (box_min < 1E-7) box_min = 1E-7;
    if (box_max < 1E-7) box_max = 1E-7;

    // ensure that something is drawn, even if length = 0 (such as all tests = 1 or 0)
    if (fabs(box_min - box_max) < 0.01) {

      TLine box_line;
      box_line.SetLineWidth(4);

      float line_pos = (box_max + box_min) / 2;
      if (types[i] == 1)
        box_line.SetLineColor(18);
      else if (testFailed[i])
        box_line.SetLineColor(kRed);
      else box_line.SetLineColor(kGreen);
      
      box_line.DrawLine(line_pos, i + 1.25, line_pos, i + 1.75);
      continue;
    }

    if (empty[i]) {
      box_min = 1E-7; box_max = 1;
      box.SetFillStyle(3005);
      box.SetFillColor(kBlack);
      box.SetLineColor(kBlack);
      box.SetLineWidth(1);
      box.SetLineStyle(1);
    } else if (testFailed[i]) {
      box.SetFillStyle(1001);
      box.SetLineStyle(0);
      box.SetLineColor(kRed);
      box.SetFillColor(kRed);
    } else {
      box.SetFillStyle(1001);
      box.SetLineStyle(0);
      box.SetLineColor(kGreen);
      box.SetFillColor(kGreen);
    }

    // draw the box
    box.DrawBox(box_min, i + 1.25, box_max, i + 1.75);

  }

  // draw the pass/fail threshold line
  TLine l(threshold, 1, threshold, num_histos + 1);
  l.SetLineColor(kRed);
  l.SetLineWidth(2);
  l.SetLineStyle(2);
  l.Draw("SAME");

  // print the results
    main_c.Print("AllResults-HistoCheck.gif","gif");

  if (combinedFailed) cout << "Final Result: fail" << endl;
  else cout << "Final Result: pass" << endl;

  //delete pc;
  return 0;

}
