#include <time.h>
#include <stdlib.h>
#include <iostream>
#include <sstream>
#include<fstream>
#include "vpp_generated.h"
#include <string.h>
using namespace std;
vpp_generated_2014_05_15 sp;
#define ES 25
unsigned valid[ES], q[ES], phi[ES], eta[ES], phib[ES], cscid[ES], clctpat[ES];

void read_input(ifstream &inputfile)
{
	char line[110];
	int d[6] = {0,0,0,0,0,0};
	int n, j = 0;
	static int first_time = 1;


	for (j = 0; ;)
	{
		if (inputfile.eof()) exit (0);
		inputfile.getline(line, 100, '\n');
		memset (d, 0, sizeof(d));
		n = sscanf
		(
			line,
			"%d %d %d %d %d %d", 
			&d[0],
			&d[1],
			&d[2],
			&d[3],
			&d[4],
			&d[5]
		);

		if (n == 3) 	
		{
			if (!first_time) break;
			else first_time = 0;
		}
		else if (n >= 5)
		{
			valid[j] = d[0];
			q[j]     = d[1];
			eta[j]   = d[2];
			phi[j]   = d[3];
			cscid[j] = d[4];
			clctpat[j] = d[5];
			j++;
		}
	}
}

#define ULLONG unsigned long long
void $readmemh(char* fname, ULLONG* mem, ULLONG astart, ULLONG afinish)
{
        std::ifstream ifs (fname , std::ifstream::in);
        ULLONG val;
        for (ULLONG i = astart; i <= afinish; i++)
        {
                if (ifs >> std::hex >> val)
                {
                        mem[i] = val;
                }
        }
        ifs.close();
}

int main(int argc, char* argv[])
{
	cout << "generated core test program" << endl;

	clock_t clk_before, clk_after, clk_spent = 0;
	unsigned ptHp, signHp,  modeMemHp,  etaPTHp,  FRHp, phiHp, phdiff_aH, phdiff_bH;
	unsigned ptMp, signMp,	modeMemMp,	etaPTMp,  FRMp, phiMp, phdiff_aM, phdiff_bM;
	unsigned ptLp, signLp,	modeMemLp,	etaPTLp,  FRLp, phiLp, phdiff_aL, phdiff_bL;

	unsigned me1idH,  me2idH,  me3idH,  me4idH,  mb1idH,  mb2idH;
	unsigned me1idM,  me2idM,  me3idM,  me4idM,  mb1idM,  mb2idM;
	unsigned me1idL,  me2idL,  me3idL,  me4idL,  mb1idL,  mb2idL;
	int ev_num = 0;
	char line[1000];

	// 3 string streams for ring buffer
	stringstream ev[3];
//	int trk_cnt[3]; // track counts from previous events
	unsigned stri = 0; // stream index

	ifstream inputfile;
	inputfile.open(argv[1], ifstream::in);
	if (!inputfile.good()) 
	{
		cout << "cannot open input file" << endl;
		exit(0);
	}
	// read two parameter lines
	inputfile.getline(line, 1000, '\n');
	inputfile.getline(line, 1000, '\n');

	int evt_total = 0;

#define MAX_EVS 14900


	for (int j = 0; j < MAX_EVS+10; j++)
	{
		read_input(inputfile);
		ev_num++;

		clk_before = clock();
		/*
		int globval = 0;
		for (int i = 0; i < 15; i++) globval |= ((valid[i] & 1) << i);
		if (globval)
//		if (globval && !valid[9] && !valid[10] && !valid[11])  // no station 3
		{
//			cout << "input valid " << endl;
		}
		else
		{
			for (int i = 0; i < ES; i++) // kill all segments 
			{
				valid[i] = 0;
				q[i] = 0;
				eta[i] = 0;
		   		phi[i] = 0;
				cscid[i] = 0;
	   		}	
		}
		*/
		sp.wrap
		(
			valid[0] , q[0], eta[0], phi[0], cscid[0], clctpat[0],
			valid[1] , q[1], eta[1], phi[1], cscid[1], clctpat[1],
			valid[2] , q[2], eta[2], phi[2], cscid[2], clctpat[2],
			valid[3] , q[3], eta[3], phi[3], cscid[3], clctpat[3],
			valid[4] , q[4], eta[4], phi[4], cscid[4], clctpat[4],
			valid[5] , q[5], eta[5], phi[5], cscid[5], clctpat[5],

			valid[6] , q[6], eta[6], phi[6],
			valid[7] , q[7], eta[7], phi[7],
			valid[8] , q[8], eta[8], phi[8],

			valid[9] , q[9],  eta[9],  phi[9],
			valid[10], q[10], eta[10], phi[10],
			valid[11], q[11], eta[11], phi[11],

			valid[12], q[12], eta[12], phi[12],
			valid[13], q[13], eta[13], phi[13],
			valid[14], q[14], eta[14], phi[14],

			valid[15], q[15], phi[15], clctpat[15],
			valid[16], q[16], phi[16], clctpat[16],
			valid[17], q[17], phi[17], clctpat[17],
			valid[18], q[18], phi[18], clctpat[18],

			ptHp,  signHp, modeMemHp, etaPTHp, FRHp, phiHp, phdiff_aH, phdiff_bH,
			ptMp,  signMp, modeMemMp, etaPTMp, FRMp, phiMp, phdiff_aM, phdiff_bM,
			ptLp,  signLp, modeMemLp, etaPTLp, FRLp, phiLp, phdiff_aL, phdiff_bL,

			me1idH,  me2idH,  me3idH,  me4idH,  mb1idH,  mb2idH, 
			me1idM,  me2idM,  me3idM,  me4idM,  mb1idM,  mb2idM, 
			me1idL,  me2idL,  me3idL,  me4idL,  mb1idL,  mb2idL, 

			// used by Joe
			/*			22,22,14,14,14,10,22,       // etamin	  
			 127,127,127,127,127,24,127,	// etamax	  
			 6,6,6,6,6,6,					// etawindow

			0xffff, 0xffff,

			0, 127, 64,   
			13, 27, 64,
   
			14, 29, 64,   
			21, 38, 64,

			0xffff, 0xffff,
			60,200,
			0, 1982,
			0x104
			*/

			// params taken from GP and Anna
			0, 0, 0, 0, 0, 0, 0, 127, 127, 127, 127, 127, 24, 127, 4, 4, 6, 6, 6, 6, 
			65535, 65535, 12, 17, 64, 13, 27, 64, 14, 29, 64, 21, 38, 64, 65535, 65535, 
			19, 15, 
			0, 1982,
			0x104
		);

		clk_after = clock();
		clk_spent += clk_after - clk_before;

		
		ev[stri].str(""); // empty ring buffer cell
//		trk_cnt[stri] = 0;
		// if (modeMemHp != 0 || modeMemLp != 0) 
		// {

		// 	//			cout << "found track" << endl;
		// 	// count tracks found in this event
		// 	if (modeMemHp != 0 && modeMemHp != 15) trk_cnt[stri]++;
		// 	if (modeMemMp != 0 && modeMemMp != 15) trk_cnt[stri]++;
		// 	if (modeMemLp != 0 && modeMemLp != 15) trk_cnt[stri]++;

		// 	evt_total++;
		// 	// print event into cell
		// 	ev[stri] << dec << "Event Number " << ev_num << endl;
		// 	ev[stri] << endl;

		// 	ev[stri] << hex << (ptHp&0xfff)	 << dec << "\t" << signHp << "\t" << modeMemHp << "\t" << etaPTHp << "\t" << FRHp << "\t" << phiHp << "\t" << (phdiff_aH & 0xfff)  << "\t" << (phdiff_bH & 0xfff) << "\t" << ((phdiff_aH>>12) & 0x7f)  << "\t" << ((phdiff_bH>>12) & 0x7f) << endl;
		// 	ev[stri] << hex << (ptMp&0xfff)	 << dec << "\t" << signMp << "\t" << modeMemMp << "\t" << etaPTMp << "\t" << FRMp << "\t" << phiMp << "\t" << (phdiff_aM & 0xfff)  << "\t" << (phdiff_bM & 0xfff) << "\t" << ((phdiff_aM>>12) & 0x7f)  << "\t" << ((phdiff_bM>>12) & 0x7f) << endl;
		// 	ev[stri] << hex << (ptLp&0xfff)	 << dec << "\t" << signLp << "\t" << modeMemLp << "\t" << etaPTLp << "\t" << FRLp << "\t" << phiLp << "\t" << (phdiff_aL & 0xfff)  << "\t" << (phdiff_bL & 0xfff) << "\t" << ((phdiff_aL>>12) & 0x7f)  << "\t" << ((phdiff_bL>>12) & 0x7f) << endl;

		// 	ev[stri] << "\nIDs: \n";

		// 	ev[stri] << oct << me1idH/8 << me1idH%8 << "\t" << me2idH/4 << me2idH%4 << "\t" << me3idH/4 << me3idH%4 << "\t" << me4idH/4 << me4idH%4 << "\t" << mb1idH/8 << mb1idH%8 << endl;
		// 	ev[stri] << oct << me1idM/8 << me1idM%8 << "\t" << me2idM/4 << me2idM%4 << "\t" << me3idM/4 << me3idM%4 << "\t" << me4idM/4 << me4idM%4 << "\t" << mb1idM/8 << mb1idM%8 << endl;
		// 	ev[stri] << oct << me1idL/8 << me1idL%8 << "\t" << me2idL/4 << me2idL%4 << "\t" << me3idL/4 << me3idL%4 << "\t" << me4idL/4 << me4idL%4 << "\t" << mb1idL/8 << mb1idL%8 << endl;
		// 	ev[stri] << endl;
	
		// 	ev[stri] << "floating  etas: " << dec << ((float)etaPTHp*1.6/32.+0.9) << "  "  << ((float)etaPTMp*1.6/32.+0.9) << "  "<< ((float)etaPTLp*1.6/32.+0.9) << endl;
		// 	ev[stri] << "converted etas: " << dec << (etaPTHp*4) << "  "  << (etaPTMp*4) << "  "<< (etaPTLp*4) << endl;

		// }

		// printout compatible with modelsim simulation
		{
			evt_total++;
			// print event into cell
			ev[stri] << dec << "Event Number " << ev_num << endl;
			ev[stri] << endl;

			ev[stri] << dec << ptHp	 << "\t" << signHp << "\t" << modeMemHp << "\t" << etaPTHp << "\t" << FRHp << "\t" << phiHp << "\t" << ((ptHp>>8)&0xf) << endl;
			ev[stri] << dec << ptMp	 << "\t" << signMp << "\t" << modeMemMp << "\t" << etaPTMp << "\t" << FRMp << "\t" << phiMp << "\t" << ((ptMp>>8)&0xf) << endl;
			ev[stri] << dec << ptLp	 << "\t" << signLp << "\t" << modeMemLp << "\t" << etaPTLp << "\t" << FRLp << "\t" << phiLp << "\t" << ((ptLp>>8)&0xf) << endl;

			ev[stri] << "\nIDs: \n";

			ev[stri] << oct << me1idH/8 << me1idH%8 << "\t" << me2idH/4 << me2idH%4 << "\t" << me3idH/4 << me3idH%4 << "\t" << me4idH/4 << me4idH%4 << "\t" << mb1idH/8 << mb1idH%8 << endl;
			ev[stri] << oct << me1idM/8 << me1idM%8 << "\t" << me2idM/4 << me2idM%4 << "\t" << me3idM/4 << me3idM%4 << "\t" << me4idM/4 << me4idM%4 << "\t" << mb1idM/8 << mb1idM%8 << endl;
			ev[stri] << oct << me1idL/8 << me1idL%8 << "\t" << me2idL/4 << me2idL%4 << "\t" << me3idL/4 << me3idL%4 << "\t" << me4idL/4 << me4idL%4 << "\t" << mb1idL/8 << mb1idL%8 << endl;
			ev[stri] << endl;
	
		}
		// just print now
		if (modeMemHp != 0 || modeMemLp != 0)		
			cout << ev[stri].str();

//		cout << sp.spvpp_ptu2a_phiA << " " << sp.spvpp_ptu2a_phiB << " " << sp.spvpp_ptu2a_phiC << endl;
//		cout << dec << sp.spvpp_ptu2a_etaA << " " << sp.spvpp_ptu2a_etaB << " " << sp.spvpp_ptu2a_etaC <<  " " << hex << sp.spvpp_me2Rankrr[0] << " " << sp.spvpp_u2aIdt << endl;

		// cout << hex << eta[0] << " " << eta[6] << endl;
		// cout << hex << sp.spvpp_me1[0] << " " << sp.spvpp_me1[1] << " " << sp.spvpp_me1[2] << " " << sp.spvpp_me1[3] << " " << sp.spvpp_me1[4] << " " << sp.spvpp_me1[5] << endl;
		// cout << hex << sp.spvpp_me2[0] << " " << sp.spvpp_me2[1] << " " << sp.spvpp_me2[2] << endl;
		// cout << hex << sp.spvpp_Eqme14 << " " << sp.spvpp_pass14 << " " << sp.spvpp_u14_3_Dphi << " " 
		// 	 << sp.spvpp_u14_3_HighP13r  << " " << sp.spvpp_u14_3_MedP13r  << " " << sp.spvpp_u14_3_LowP13r << " "
		// 	 << sp.spvpp_u14_3_qA  << " " << sp.spvpp_u14_3_qB  << " " << sp.spvpp_u14_3_validA << " "  << sp.spvpp_u14_3_validB << " "
		// 	 << sp.spvpp_u14_3_passX  << " " << sp.spvpp_u14_3_passY  << " " << sp.spvpp_u14_3_passZ << " " 
		// 	 << sp.spvpp_u14_3_CSCidA  << " " << sp.spvpp_u14_3_CSCidY  << " " << sp.spvpp_u14_3_CSCidZ << " " <<  sp.spvpp_u14_3_wide_phi
		// 	<< endl;
		// 	<< sp.spvpp_u12_0_validA << " " << sp.spvpp_u12_0_validB << endl;
		/*
		// looking for 3 muons (ghosts) in a single event
		if (trk_cnt[stri] > expected_trk_cnt) 
		{
			cout << "SINGLE event ghosts" << endl;
			cout << ev[stri].str();
		}
		
		// looking for ghosts in consequtive events
		if (modeMemHp != 0 || modeMemLp != 0) // current event has track
		{
			// check -1 and -2
			unsigned ago1 = (stri + 2) % 3;
			unsigned ago2 = (stri + 1) % 3;

			if (ago1 > 2 || ago2 > 2) 
	        {
				cout << "illegal indexes: " << ago2 << " " << ago1 << " " << stri << endl;
			}

			// count all tracks found in 3 events
			int tot_trk = trk_cnt[ago2] + trk_cnt[ago1] + trk_cnt[stri];	

			//			if (!ev[ago2].str().empty() || !ev[ago1].str().empty()) 
			if (tot_trk > expected_trk_cnt) 
			{
				cout << "MULTIPLE event ghosts " << ago2 << " " << ago1 << " " << stri << endl;

				if (!ev[ago2].str().empty()) {cout << ev[ago2].str();}
				if (!ev[ago1].str().empty()) {cout << ev[ago1].str();}
				cout << ev[stri].str();
			}
		}
		
		*/
		stri = (stri + 1) % 3;
		
	}
	cout << "Elapsed time: " << dec << clk_spent/(CLOCKS_PER_SEC/1000) << " ms" << endl;
	cout << "Total tracks found: " << evt_total << endl;
}
