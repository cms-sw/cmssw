#include <time.h>
#include <stdlib.h>
#include <iostream>
#include <sstream>
#include <iomanip>
#include "vpp_generated.h"
using namespace std;
vpp_generated_2014_05_15 sp;
#define ES 23
unsigned valid[ES], q[ES], phi[ES], eta[ES], phib[ES], cscid[ES], clctpat[ES];

int main()
{
	clock_t clk_before, clk_after, clk_spent = 0;
	int i;
	unsigned ptHp, signHp,  modeMemHp,  etaPTHp,  FRHp, phiHp;
	unsigned ptMp, signMp,  modeMemMp,  etaPTMp,  FRMp, phiMp;
	unsigned ptLp, signLp,  modeMemLp,  etaPTLp,  FRLp, phiLp;

	unsigned me1id[3],  me2id[3],  me3id[3],  me4id[3],  mb1id[3],  mb2id[3];
	int ev_num = 1;


#define MAX_EVS 10000

	srand(876);

	for (int j = 0; j < MAX_EVS+10; j++)
	{

		// generate random numbers for each input param	

		if (j > 10)
			for (i = 0; i < ES; i++)
			{
				valid[i] = rand();
				q[i] = rand();
				eta[i] = rand();
				phi[i] = rand();
				cscid[i] = rand();
				clctpat[i] = rand();
			}	
		else
			for (i = 0; i < ES; i++) // run zeroes first 10 events to zero out all the garbage that may have been left in logic
			{
				valid[i] = 0;
				q[i] = 0;
				eta[i] = 0;
		   		phi[i] = 0;
				cscid[i] = 0;
				clctpat[i] = 0;
	   		}	

		// remove dt stub 0 or 1 randomly, to allow for serialization
		if (rand() & 1) q[15] = 0;
		if (rand() & 1) q[16] = 0;

		clk_before = clock();

		sp.wrap
		(
			valid[0] , q[0], eta[0], phi[0], cscid[0], clctpat[0],
			valid[1] , q[1], eta[1], phi[1], cscid[1], clctpat[1],
			valid[2] , q[2], eta[2], phi[2], cscid[2], clctpat[2],
			valid[3] , q[3], eta[3], phi[3], cscid[3], clctpat[3],
			valid[4] , q[4], eta[4], phi[4], cscid[4], clctpat[4],
			valid[5] , q[5], eta[5], phi[5], cscid[5], clctpat[5],

			valid[6] , q[6], eta[6], phi[6],
			valid[7] , q[7], eta[7], phi[7],
			valid[8] , q[8], eta[8], phi[8],

			valid[9] , q[9],  eta[9],  phi[9],
			valid[10], q[10], eta[10], phi[10],
			valid[11], q[11], eta[11], phi[11],

			valid[12], q[12], eta[12], phi[12],
			valid[13], q[13], eta[13], phi[13],
			valid[14], q[14], eta[14], phi[14],

			valid[15], q[15], phi[15], clctpat[15],
			valid[16], q[16], phi[16], clctpat[16],
			valid[17], q[17], phi[17], clctpat[17],
			valid[18], q[18], phi[18], clctpat[18],

			ptHp,  signHp, modeMemHp, etaPTHp, FRHp, phiHp,
			ptMp,  signMp, modeMemMp, etaPTMp, FRMp, phiMp,
			ptLp,  signLp, modeMemLp, etaPTLp, FRLp, phiLp,

			me1id[0],  me2id[0],  me3id[0],  me4id[0],  mb1id[0],  mb2id[0], 
			me1id[1],  me2id[1],  me3id[1],  me4id[1],  mb1id[1],  mb2id[1], 
			me1id[2],  me2id[2],  me3id[2],  me4id[2],  mb1id[2],  mb2id[2], 

			// parameters below are such that any eta will pass
			22,22,14,14,14,10,22,      // etamin	  
			127,127,127,127,127,24,127,	// etamax	  
			6,6,6,6,6,6,	// etawindow

			//			180, 7, 
			0xffff, 0xffff,

			0,127, 64,   
			13,27, 64,
   
			14,29, 64,   
			21,38, 64,

			//			128, 8, 
			0xffff, 0xffff,
			60, 200,

			0, 1982,
//			(-10)&0x1fff, (-20)&0x1fff,

			0x104
		);

		clk_after = clock();
		clk_spent += clk_after - clk_before;

		cout << dec << "Event Number " << ev_num++ << endl;

		cout << dec << ptHp  << "\t" << signHp << "\t" << modeMemHp << "\t" << etaPTHp << "\t" << FRHp << "\t" << phiHp << endl;
		cout << dec << ptMp  << "\t" << signMp << "\t" << modeMemMp << "\t" << etaPTMp << "\t" << FRMp << "\t" << phiMp << endl;
		cout << dec << ptLp  << "\t" << signLp << "\t" << modeMemLp << "\t" << etaPTLp << "\t" << FRLp << "\t" << phiLp << endl;

		cout << "\nIDs: \n";

		int me1del[3] = {(me1id[0]>>3), (me1id[1]>>3), (me1id[2]>>3)}; 
		int me2del[3] = {(me2id[0]>>2), (me2id[1]>>2), (me2id[2]>>2)}; 
		int me3del[3] = {(me3id[0]>>2), (me3id[1]>>2), (me3id[2]>>2)}; 
		int me4del[3] = {(me4id[0]>>2), (me4id[1]>>2), (me4id[2]>>2)}; 
		int mb1del[3] = {(mb1id[0]>>3), (mb1id[1]>>3), (mb1id[2]>>3)}; 

		cout << me1del[0] << (me1id[0]&7)  << "\t" << me2del[0] << (me2id[0]&3) << "\t" << me3del[0] << (me3id[0]&3)  
			 << "\t" << me4del[0] << (me4id[0]&3)  << "\t" << mb1del[0] << (mb1id[0]&7) << endl;

		cout << me1del[1] << (me1id[1]&7)  << "\t" << me2del[1] << (me2id[1]&3) << "\t" << me3del[1] << (me3id[1]&3)  
			 << "\t" << me4del[1] << (me4id[1]&3)  << "\t" << mb1del[1] << (mb1id[1]&7) << endl;

		cout << me1del[2] << (me1id[2]&7)  << "\t" << me2del[2] << (me2id[2]&3) << "\t" << me3del[2] << (me3id[2]&3)  
			 << "\t" << me4del[2] << (me4id[2]&3)  << "\t" << mb1del[2] << (mb1id[2]&7) << endl;

		cout << endl;
	}
	cout << "Elapsed time: " << dec << clk_spent/(CLOCKS_PER_SEC/1000) << " ms" << endl;
}
